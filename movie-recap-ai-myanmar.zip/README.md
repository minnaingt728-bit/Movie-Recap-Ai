# Movie Recap AI — Myanmar Mobile Starter

## လိုအပ်ချက်
- Node.js 20+ (nodejs.org)
- AI generation ကို တကယ်သုံးရန် OpenAI API key (မဖြစ်မနေမဟုတ်ပါ။ Key မရှိလျှင် demo template ပြန်ပေးမည်။)

## ဖွင့်နည်း
1. ZIP ကို ဖြည်ပါ။
2. Project folder ထဲမှာ terminal ဖွင့်ပြီး `npm install` လုပ်ပါ။
3. `.env.example` ကို `.env` အဖြစ်ကူးပါ။
4. AI လိုလျှင် `.env` ထဲတွင် `OPENAI_API_KEY=သင့်_API_KEY` ထည့်ပြီး `JWT_SECRET` ကို ရှည်လျားကျပန်းစာသားဖြင့် ပြောင်းပါ။
5. Terminal ပထမခုတွင် `npm run server` လုပ်ပါ။
6. Terminal ဒုတိယခုတွင် `npm run dev` လုပ်ပါ။
7. Terminal ပြထားသော Vite URL ကို browser ဖြင့်ဖွင့်ပါ။ ပုံမှန်အားဖြင့် `http://localhost:5173` ဖြစ်သည်။

## ပါဝင်သည့် Feature
- Mobile-first Myanmar UI
- Register / Login (local JSON file + bcrypt + JWT demo)
- Video upload (150 MB limit; `uploads/` ထဲသိမ်း)
- AI script, summary, subtitle draft (API key မရှိလျှင် demo template)
- Browser Text-to-Speech voice (မြန်မာအသံသည် device/browser အလိုက်ကွာခြား)
- TXT နှင့် SRT download

## အရေးကြီးသော ကန့်သတ်ချက်
- ဒီ project သည် စတင်အသုံးပြုနိုင်သော MVP/starter ဖြစ်သည်၊ production service အဖြစ် မတင်ရသေးပါ။
- Uploaded movie ဖိုင်မှ ဇာတ်လမ်းကို အလိုအလျောက် နားလည်ဖတ်ရှုခြင်း မပါသေးပါ။ လက်ရှိတွင် plot notes ကို ကိုယ်တိုင်ထည့်ရမည်။
- MP4 video rendering/export မပါသေးပါ။ တကယ့် video export အတွက် FFmpeg၊ subtitle burn-in၊ TTS audio generation နှင့် background job/storage ကို ထပ်တည်ဆောက်ရမည်။
- Register အချက်အလက်ကို `server/users.json` ထဲသိမ်းသောကြောင့် production အတွက် database သို့ပြောင်းရန်လိုသည်။ Rate limiting, HTTPS, CSRF/origin controls, upload malware scanning, file retention rules တို့ကို ထည့်ပါ။
- မူပိုင်ခွင့်ရှိသော ရုပ်ရှင်ကို upload/အသုံးပြုရာတွင် သက်ဆိုင်ရာခွင့်ပြုချက်ကို လိုက်နာပါ။

## Project structure
```
movie-recap-ai/
├── index.html
├── package.json
├── .env.example
├── README.md
├── src/
│   ├── main.jsx
│   ├── App.jsx
│   └── style.css
├── server/
│   ├── index.js
│   └── users.json       # ပထမ run မှာ auto-create လုပ်သည်
└── uploads/             # ပထမ run မှာ auto-create လုပ်သည်
```
